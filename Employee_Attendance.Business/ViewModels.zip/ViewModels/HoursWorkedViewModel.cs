﻿namespace Employee_Attendance.Business
{
   public class HoursWorkedViewModel
    {
        public string  Hours{ get; set; }
        public string HoursRemaing{ get; set; }
    }
}
